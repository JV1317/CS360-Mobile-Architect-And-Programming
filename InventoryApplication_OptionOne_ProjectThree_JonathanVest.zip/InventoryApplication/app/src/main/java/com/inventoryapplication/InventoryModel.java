package com.inventoryapplication;

public class InventoryModel {

    // string item_name for storing course_name
    // and item_q for storing item quanity.
    private String item_name;
    private int item_q;

    public InventoryModel(String item_name, int item_q){
        this.item_name = item_name;
        this.item_q = item_q;
    }

    public String getItem_name(){
        return item_name;
    }

    public void setItem_name(String item_name){
        this.item_name = item_name;
    }

    public int getItem_q(){
        return item_q;
    }

    public void setItem_q(int item_q){
        this.item_q = item_q;
    }
}

