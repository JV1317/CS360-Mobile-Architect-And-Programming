package com.inventoryapplication;

import android.os.Bundle;
import android.widget.GridView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class ViewItems extends AppCompatActivity {

    GridView inventoryGV;
    private List<String> mData;
    private InventoryAdapter mAdapter;
    DataBaseHelper myDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_grid);

        myDB = new DataBaseHelper(ViewItems.this);
        inventoryGV = findViewById(R.id.gridView);

        ArrayList<InventoryModel> inventoryModelArrayList;
        inventoryModelArrayList = myDB.readItems();

        InventoryAdapter adapter = new InventoryAdapter(this, inventoryModelArrayList);

        inventoryGV.setAdapter(adapter);



    }

}
