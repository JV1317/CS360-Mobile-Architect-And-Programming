package com.inventoryapplication;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    private EditText addItem, addCount;
    private static final int PERMISSION_REQUEST_SMS = 123;
    private Button permissionButton, addButton, viewItemsButton, deleteButton, updateButton;
    DataBaseHelper myDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myDB = new DataBaseHelper(MainActivity.this);

        addItem = findViewById(R.id.itemName);
        addCount = findViewById(R.id.itemCount);

        addButton = findViewById(R.id.buttonAddData);
        addButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                String itemName = addItem.getText().toString();
                String itemCount = addCount.getText().toString();

                if (itemName.isEmpty() || itemCount.isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean isInserted = myDB.addNewItem(itemName, itemCount);
                if(isInserted = true){
                    Toast.makeText(MainActivity.this, "Item Added", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(MainActivity.this, "Item not inserted", Toast.LENGTH_SHORT).show();
                }
            }
        });

        deleteButton = findViewById(R.id.deleteButton);
        deleteButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                String itemName = addItem.getText().toString();

                if (itemName.isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter item name", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean isDeleted = myDB.deleteItem(itemName);
                if(isDeleted = true){
                    Toast.makeText(MainActivity.this, "Item Removed", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(MainActivity.this, "Item not Removed", Toast.LENGTH_SHORT).show();
                }
            }
        });

        updateButton = findViewById(R.id.updateButton);
        updateButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                String itemName = addItem.getText().toString();
                String itemCount = addItem.getText().toString();

                if (itemName.isEmpty() || itemCount.isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter all data...", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean isUpdated = myDB.updateItem(itemName,itemCount);
                if(isUpdated = true){
                    Toast.makeText(MainActivity.this, "Item Updated", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(MainActivity.this, "Item not Updated", Toast.LENGTH_SHORT).show();
                }
            }
        });

        viewItemsButton = findViewById(R.id.viewItemsButton);
        viewItemsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ViewItems.class);
                startActivity(intent);
            }
        });



        permissionButton = findViewById(R.id.permissionButton);
        //notificationText = findViewById(R.id.notificationText);

        permissionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestSmsPermission();
            }
        });

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            // Permission already granted, display notifications
            //displayNotifications();
        }
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission not granted, request it
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    PERMISSION_REQUEST_SMS);
        } else {
            // Permission already granted, display notifications
            //displayNotifications();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, display notifications
                //displayNotifications();
            }
        }
    }

    /*private void displayNotifications() {
        notificationText.setText("Low inventory notification");
    }
     */



}