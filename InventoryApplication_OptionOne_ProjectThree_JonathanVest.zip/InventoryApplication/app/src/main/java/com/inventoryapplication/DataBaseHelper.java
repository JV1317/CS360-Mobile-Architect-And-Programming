package com.inventoryapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DataBaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "Inventory.db";
    private static final int VERSION = 1;

    private  static final class UserTable{
        private static final String TABLE = "users";
        public static final String COL_ID = "UserID";
        private static final String COL_NAME = "UserName";
        public static final String COL_PW = "UserPassword";
    }

    private  static final class ItemTable{
        private static final String TABLE = "Item";
        public static final String COL_NAME = "ItemName";
        public static final String COL_COUNT = "ItemCOUNT";
    }


    public DataBaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, VERSION);
        SQLiteDatabase db = this.getWritableDatabase();

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + UserTable.TABLE + " ("
                //+ UserTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + UserTable.COL_NAME + " TEXT, "
                + UserTable.COL_PW + " TEXT)");

        db.execSQL("create table " + ItemTable.TABLE + " ("
                + ItemTable.COL_NAME + " TEXT,"
                + ItemTable.COL_COUNT + " INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        onCreate(db);

        db.execSQL("drop table if exists " + ItemTable.TABLE);
        onCreate(db);
    }

    public Boolean loginUser(String userName, String userPW){
        // on below line we are creating a variable for
        // our sqlite database and calling writable method
        // as we are writing data in our database.
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursorUsers = db.rawQuery("Select * From UserTable where userName = ? and userPW = ?", new String[]{userName, userPW});

        if(cursorUsers.getCount()>0){
            return true;
        }
        else{
            return false;
        }
    }

    public void addNewUser(String userName, String userPW){
        // on below line we are creating a variable for
        // our sqlite database and calling writable method
        // as we are writing data in our database.
        SQLiteDatabase db = this.getWritableDatabase();

        // on below line we are creating a
        // variable for content values.
        ContentValues user = new ContentValues();

        // on below line we are passing all values
        // along with its key and value pair.
        user.put(UserTable.COL_NAME, userName);
        user.put(UserTable.COL_PW, userPW);

        // after adding all values we are passing
        // content values to our table.
        db.insert(UserTable.TABLE, null, user);

        // at last we are closing our
        // database after adding database.
        db.close();
    }

    public void updateUser(String userPW){
        // on below line we are creating a variable for
        // our sqlite database and calling writable method
        // as we are writing data in our database.
        SQLiteDatabase db = this.getWritableDatabase();

        // on below line we are creating a
        // variable for content values.
        ContentValues user = new ContentValues();

        // on below line we are passing all values
        // along with its key and value pair.
        user.put(UserTable.COL_PW, userPW);

        // after adding all values we are passing
        // content values to our table.
        db.update(UserTable.TABLE, user,ItemTable.COL_NAME + " = ?", new String[]{userPW});

        // at last we are closing our
        // database after adding database.
        db.close();
    }

    public boolean addNewItem(String itemName, String itemCount){
        // on below line we are creating a variable for
        // our sqlite database and calling writable method
        // as we are writing data in our database.
        SQLiteDatabase db = this.getWritableDatabase();

        // on below line we are creating a
        // variable for content values.
        ContentValues item = new ContentValues();

        // on below line we are passing all values
        // along with its key and value pair.
        item.put(ItemTable.COL_NAME, itemName);
        item.put(ItemTable.COL_COUNT, itemCount);

        // after adding all values we are passing
        // content values to our table.
        long result = db.insert(ItemTable.TABLE, null, item);
        if(result == -1){
            return false;
        }
        else{
            // at last we are closing our
            // database after adding database.
            db.close();
            return true;
        }
    }

    public boolean deleteItem(String itemName){
        // on below line we are creating a variable for
        // our sqlite database and calling writable method
        // as we are writing data in our database.
        SQLiteDatabase db = this.getWritableDatabase();

        long result = db.delete(ItemTable.TABLE, ItemTable.COL_NAME + " = ?", new String[]{itemName});
        if(result == -1){
            return false;
        }
        else{
            // at last we are closing our
            // database after adding database.
            db.close();
            return true;
        }
    }

    public boolean updateItem(String itemName, String itemCount){
        // on below line we are creating a variable for
        // our sqlite database and calling writable method
        // as we are writing data in our database.
        SQLiteDatabase db = this.getWritableDatabase();

        // on below line we are creating a
        // variable for content values.
        ContentValues item = new ContentValues();

        // on below line we are passing all values
        // along with its key and value pair.
        item.put(ItemTable.COL_NAME, itemName);
        item.put(ItemTable.COL_COUNT, itemCount);

        // after adding all values we are passing
        // content values to our table.
        long result = db.update(ItemTable.TABLE, item,ItemTable.COL_NAME + " = ?", new String[]{itemName});
        if(result == -1){
            return false;
        }
        else{
            // at last we are closing our
            // database after adding database.
            db.close();
            return true;
        }
    }

    public ArrayList<InventoryModel> readItems(){
        SQLiteDatabase db = this.getReadableDatabase();

        // on below line we are creating a cursor with query to
        // read data from database.
        Cursor cursorItems = db.rawQuery("SELECT * FROM " + ItemTable.TABLE, null);

        // on below line we are creating a new array list.
        ArrayList<InventoryModel> inventoryModelArrayList = new ArrayList<>();

        if(cursorItems.moveToFirst()){
            do{
                inventoryModelArrayList.add(new InventoryModel(cursorItems.getString(0),
                        cursorItems.getInt(1)));
            }while(cursorItems.moveToNext());
        }
        cursorItems.close();
        return inventoryModelArrayList;
    }
}
