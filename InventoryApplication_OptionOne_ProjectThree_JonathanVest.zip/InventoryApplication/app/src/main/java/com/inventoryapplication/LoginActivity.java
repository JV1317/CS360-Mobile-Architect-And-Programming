package com.inventoryapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    private EditText userAddName, userAddPW, userEditPW;
    private Button btnregister;
    private Button loginbtn;
    private Button btnforgotpwd;
    DataBaseHelper myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        myDb = new DataBaseHelper(LoginActivity.this);

        TextView username = findViewById(R.id.userName);
        TextView password = findViewById(R.id.pwd);

        loginbtn = (Button) findViewById(R.id.loginbtn);
        btnforgotpwd = (Button) findViewById(R.id.btnforgotpwd);
        btnregister = (Button) findViewById(R.id.btnregister);
        userAddName = findViewById(R.id.userName);
        userAddPW = findViewById(R.id.pwd);
        userEditPW = findViewById(R.id.pwd);

        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userName = userAddName.getText().toString();
                String userPW = userAddPW.getText().toString();

                if(username.getText().toString().equals("admin") && password.getText().toString().equals("admin")){
                    Toast.makeText(LoginActivity.this, "Login Success", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                }

                // validating if the text fields are empty or not.
                if (userName.isEmpty() && userPW.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean checkuser = myDb.loginUser(userName,userPW);
                if (checkuser == true){
                Toast.makeText(LoginActivity.this, "Login Success", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
                } else
                    //incorrect
                    Toast.makeText(LoginActivity.this, "Login Fail", Toast.LENGTH_SHORT).show();

            }
        });

        btnforgotpwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String userPW = userEditPW.getText().toString();

                myDb.updateUser(userPW);

                Toast.makeText(LoginActivity.this, "User Updated", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        btnregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userName = userAddName.getText().toString();
                String userPW = userAddPW.getText().toString();

                // validating if the text fields are empty or not.
                if (userName.isEmpty() && userPW.isEmpty()){
                    Toast.makeText(LoginActivity.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }

                myDb.addNewUser(userName, userPW);

                Toast.makeText(LoginActivity.this, "User Added", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}

